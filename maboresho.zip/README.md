# Mfumo wa TAG KCMC

Mfumo huu ni tovuti tuli (HTML, CSS na JavaScript). Hauhitaji seva ya Node.js, Python wala hifadhidata. Mipangilio (jina, picha ya wasifu, lugha, mandhari), matangazo, nyimbo na mipangilio ya TV huhifadhiwa kwenye kivinjari (localStorage) cha kompyuta unayotumia.

## Faili za mfumo

- `index.html`: ukurasa wa mwalimu
- `tv.html`: skrini ya TV (hufunguliwa na kitufe cha **WASHA TV**, mawasiliano kwa BroadcastChannel)
- `camera.html`: kamera ya simu
- `biblia.xml`: Biblia ya Kiswahili
- `tenzi-data.json`: nyimbo (weka kwenye folda ile ile kama zipo)
- `nembo.png`: nembo
- `login.html`: inaelekeza kwenye `index.html` tu (kwa viungo vya zamani)
- `manifest.webmanifest`, `sw.js`, `pwa.js`, `icons/`: huwezesha kusakinisha mfumo kama programu (shortcut) na kuufanya ufanye kazi bila intaneti

## Kuendesha kwenye kompyuta

1. Hakikisha Python 3 imewekwa.
2. Bonyeza mara mbili `anza.bat`. Hufungua `http://127.0.0.1:5500/index.html`.

## Kupeleka kwenye Vercel (kupitia GitHub)

1. Pakia faili zote za folda hii kwenye GitHub repository.
2. Kwenye Vercel, ingiza repository. **Framework Preset**: Other. Acha Build Command na Output Directory wazi.
3. Deploy. Hakuna Environment Variables zinazohitajika.

Hakikisha repository haina tena `api/`, `server.py`, `vercel.json` ya zamani (yenye `rewrites` za `/api/...`), `package-lock.json` ya zamani wala `kanisa.sqlite3`.

## Kumbuka

- Data huhifadhiwa kwa kila kivinjari na kila anwani (domain). Ukitumia kompyuta au kivinjari kingine, mipangilio na matangazo hayahamii yenyewe.
- Kamera ya simu inahitaji HTTPS (Vercel hutoa HTTPS moja kwa moja).

## Kusakinisha kama programu (shortcut)

Mtu akifungua kiungo cha mfumo kwenye Chrome au Edge (kompyuta au Android), kadi ya **Weka shortcut ya TAG KCMC** hutokea chini ya skrini. Akibonyeza **Weka shortcut**, mfumo husakinishwa kama programu yenye ikoni ya TAG, hufunguka kwenye dirisha lake, na unaweza kuuweka kwenye desktop, Start menu au taskbar. Akibonyeza **Baadaye**, kadi inafichwa kwa siku 7 na kitufe kidogo cha **⬇ Weka shortcut** kinabaki kwenye kona.

- iPhone/iPad (Safari): kadi inaonyesha maelekezo ya **Shiriki → Ongeza kwenye Skrini ya Nyumbani**.
- Usakinishaji unahitaji HTTPS (Vercel hutoa) au `localhost`/`127.0.0.1` (anza.bat).
- Ukibadilisha `biblia.xml`, `tenzi-data.json` au picha, badilisha `VERSION` ndani ya `sw.js` (mfano `kcmc-v2`) ili vifaa vichukue toleo jipya. Kurasa za HTML na JS husasishwa zenyewe mtandao ukipatikana.
