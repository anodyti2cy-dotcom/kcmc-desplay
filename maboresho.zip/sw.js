/* Service worker ya TAG KCMC: huruhusu mfumo kusakinishwa na kufanya kazi bila intaneti.
   Ukibadilisha biblia.xml au tenzi-data.json, ongeza namba ya VERSION hapa chini. */
const VERSION = 'kcmc-v1';
const SHELL = ['./', 'index.html', 'tv.html', 'camera.html', 'manifest.webmanifest', 'pwa.js', 'nembo.png',
  'icons/icon-192.png', 'icons/icon-512.png'];
const CDN = /^https:\/\/(cdnjs\.cloudflare\.com|unpkg\.com|cdn\.jsdelivr\.net)\//;

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION)
    .then(c => Promise.all(SHELL.map(u => c.add(u).catch(() => {}))))
    .then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(keys => Promise.all(keys.filter(k => k.startsWith('kcmc-') && k !== VERSION).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

// Kurasa na msimbo: mtandao kwanza (mabadiliko mapya yaonekane), akiba kama hakuna mtandao.
async function networkFirst(req) {
  const cache = await caches.open(VERSION);
  try {
    const res = await fetch(req);
    if (res && res.ok) cache.put(req, res.clone());
    return res;
  } catch (_) {
    const hit = await cache.match(req, { ignoreSearch: true });
    return hit || (req.mode === 'navigate' ? await cache.match('index.html') : null) || Response.error();
  }
}

// Faili kubwa na picha: toa akiba mara moja, sasisha nyuma ya pazia.
async function staleWhileRevalidate(event) {
  const req = event.request, cache = await caches.open(VERSION), hit = await cache.match(req);
  const fresh = fetch(req).then(res => {
    if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
    return res;
  }).catch(() => null);
  if (hit) { event.waitUntil(fresh); return hit; }
  return (await fresh) || Response.error();
}

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || req.headers.has('range')) return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) {
    if (CDN.test(req.url)) event.respondWith(staleWhileRevalidate(event));
    return;
  }
  if (req.mode === 'navigate' || /\.(html|js|webmanifest)$/.test(url.pathname)) event.respondWith(networkFirst(req));
  else event.respondWith(staleWhileRevalidate(event));
});
