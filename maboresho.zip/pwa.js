/* Usakinishaji wa mfumo (shortcut/programu) kwa TAG KCMC.
   - Husajili service worker (sw.js)
   - Huonyesha kadi ya "Weka shortcut" mtu anapofungua kiungo
   - iPhone/iPad: huonyesha maelekezo ya "Ongeza kwenye Skrini ya Nyumbani" */
(() => {
  const KEY = 'kcmcInstallDismissed', DAYS = 7;
  const secure = location.protocol === 'https:' || ['localhost', '127.0.0.1'].includes(location.hostname);
  if ('serviceWorker' in navigator && secure) addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));

  const standalone = () => matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: window-controls-overlay)').matches || navigator.standalone === true;
  if (standalone()) return;

  const ios = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const store = { get: k => { try { return localStorage.getItem(k) } catch (_) { return null } }, set: (k, v) => { try { localStorage.setItem(k, v) } catch (_) {} } };
  const dismissed = () => Date.now() - (+store.get(KEY) || 0) < DAYS * 864e5;
  let ev = null, card = null, chip = null;

  const css = document.createElement('style');
  css.textContent = `
  .kpw-card{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:2000;width:min(94vw,440px);display:flex;gap:12px;align-items:center;padding:14px 16px;background:#fff;color:#182230;border:1px solid #d0d5dd;border-radius:14px;box-shadow:0 14px 44px #0005;font:14px/1.4 'Segoe UI',Arial,sans-serif}
  .kpw-card img{width:46px;height:46px;border-radius:10px;flex:none}
  .kpw-card b{display:block;font-size:15px;margin-bottom:2px}
  .kpw-card small{display:block;color:#475467}
  .kpw-btns{display:flex;gap:8px;margin-top:8px}
  .kpw-btns button{margin:0;width:auto;padding:8px 14px;border:0;border-radius:8px;font:inherit;font-weight:700;cursor:pointer;background:#e4e7ec;color:#344054}
  .kpw-btns button.kpw-go{background:#1565c0;color:#fff}
  .kpw-chip{position:fixed;right:16px;bottom:16px;z-index:2000;margin:0;width:auto;padding:10px 14px;border:0;border-radius:999px;background:#1565c0;color:#fff;font:700 13px 'Segoe UI',Arial,sans-serif;cursor:pointer;box-shadow:0 8px 24px #0004}`;
  document.head.appendChild(css);

  const hide = () => { card && card.remove(); chip && chip.remove(); card = chip = null };
  function later() { store.set(KEY, Date.now()); card && card.remove(); card = null; if (ev) showChip() }
  function showCard(html, goLabel, onGo) {
    hide();
    card = document.createElement('div'); card.className = 'kpw-card'; card.setAttribute('role', 'region'); card.setAttribute('aria-label', 'Weka shortcut');
    card.innerHTML = `<img src="icons/icon-192.png" alt=""><div>${html}<div class="kpw-btns"><button class="kpw-go" type="button">${goLabel}</button><button class="kpw-no" type="button">Baadaye</button></div></div>`;
    card.querySelector('.kpw-go').onclick = onGo; card.querySelector('.kpw-no').onclick = later;
    document.body.appendChild(card);
  }
  function showChip() {
    if (chip || !ev) return;
    chip = document.createElement('button'); chip.type = 'button'; chip.className = 'kpw-chip'; chip.textContent = '⬇ Weka shortcut';
    chip.onclick = install; document.body.appendChild(chip);
  }
  async function install() {
    if (!ev) return;
    const e = ev; ev = null; hide();
    try { e.prompt(); await e.userChoice } catch (_) {}
  }
  function showIos() {
    showCard('<b>Weka TAG KCMC kwenye Skrini ya Nyumbani</b><small>Gusa kitufe cha <b style="display:inline">Shiriki ⬆</b> chini ya Safari, kisha chagua <b style="display:inline">“Ongeza kwenye Skrini ya Nyumbani”</b>.</small>', 'Sawa', later);
  }
  function showInstall() {
    showCard('<b>Weka shortcut ya TAG KCMC</b><small>Sakinisha mfumo kama programu ili uufungue haraka kutoka kwenye desktop au skrini ya nyumbani, hata bila intaneti.</small>', 'Weka shortcut', install);
  }

  addEventListener('beforeinstallprompt', e => { e.preventDefault(); ev = e; dismissed() ? showChip() : showInstall() });
  addEventListener('appinstalled', () => { ev = null; hide(); store.set(KEY, Date.now()) });
  if (ios && !dismissed()) addEventListener('load', () => setTimeout(showIos, 1200));

  // Kwa kitufe chochote chako mwenyewe: onclick="kcmcWekaShortcut()"
  window.kcmcWekaShortcut = () => ev ? install() : ios ? showIos() : alert('Kivinjari hiki hakitoi chaguo la kusakinisha sasa. Kwenye Chrome/Edge tumia menyu (⋮) kisha “Sakinisha programu” au “Weka njia ya mkato”.');
})();
